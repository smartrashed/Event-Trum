<?php

function event_term_google_map($el_class) {?>    
    <!--  start contact section   -->
    <section class="section-google-map">
        <div id="map" class="et-googlemap"></div>
    </section>    
    <!--  end contact section   -->    
<?php }
