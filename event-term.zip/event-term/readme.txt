Theme Name: Event Term
Author: CodexCoder

Event Term is a highly customizable WordPress theme for any kind of event like conference, meet-up, musical concert. 

The documentations is here:
http://docs.codexcoder.com/event-term


For any kind of support please feel free to contact us any time :) . 
Our support email is:
support@codexcoder.com 